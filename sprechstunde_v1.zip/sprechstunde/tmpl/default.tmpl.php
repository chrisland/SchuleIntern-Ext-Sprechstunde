<div class="box">
	<div class="box-body">
        <?php if ($info): ?>
            <div class="si-hinweis"><?= $info ?></div>
        <?php endif; ?>
		<div id="app"></div>
	</div>
</div>